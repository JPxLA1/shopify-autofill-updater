// --- Crypto Helpers (PBKDF2 + AES-256-GCM) ---
async function getCryptoKey(password) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: enc.encode('shopify-profile-salt-static'),
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt']
  );
}

async function decryptData(cipherPackage, password) {
  try {
    const key = await getCryptoKey(password);
    const iv = new Uint8Array(cipherPackage.iv);
    const encrypted = new Uint8Array(cipherPackage.cipher);
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv },
      key,
      encrypted
    );
    return JSON.parse(new TextDecoder().decode(decrypted));
  } catch (err) {
    return null;
  }
}

let queue = {
  active: false,
  cartUrl: '',
  profiles: [],
  currentIndex: 0,
  discount: '',
  tabId: null
};

async function safeNavigateTab(url) {
  if (queue.tabId) {
    try {
      const tab = await chrome.tabs.get(queue.tabId);
      if (tab) {
        await chrome.tabs.update(queue.tabId, { url });
        return;
      }
    } catch {}
  }

  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab && activeTab.id) {
    queue.tabId = activeTab.id;
    await chrome.tabs.update(activeTab.id, { url });
  } else {
    const newTab = await chrome.tabs.create({ url, active: true });
    queue.tabId = newTab.id;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 1. Webhook Dispatcher
  if (message.action === 'SEND_DISCORD_WEBHOOK') {
    if (message.webhookUrl) {
      fetch(message.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(message.payload)
      }).catch(console.error);
    }
    sendResponse({ success: true });
    return true;
  }

  // 2. Start Batch Queue
  if (message.action === 'START_QUEUE') {
    queue.active = true;
    queue.cartUrl = message.cartUrl;
    queue.profiles = message.profiles;
    queue.currentIndex = 0;
    queue.discount = message.discount || '';
    queue.tabId = message.tabId;

    safeNavigateTab(queue.cartUrl);
    sendResponse({ status: 'QUEUE_STARTED' });
    return true;
  }

  // 3. Manual Single Profile Execution (Immediate Trigger)
  if (message.action === 'EXECUTE_PROFILE_NOW') {
    (async () => {
      const storage = await chrome.storage.local.get(null);
      const password = storage.masterPassword || 'default-local-key';
      const cipher = storage[`profile_${message.profileNum}`];

      if (!cipher) {
        sendResponse({ success: false, error: 'Profile not saved' });
        return;
      }

      const decrypted = await decryptData(cipher, password);
      if (!decrypted) {
        sendResponse({ success: false, error: 'Decryption failed' });
        return;
      }

      const profilePayload = {
        ...decrypted,
        profileNumber: message.profileNum,
        discountCode: message.discount || storage.savedDiscountCode || '',
        webhookUrl: storage.discordWebhook || null
      };

      chrome.tabs.sendMessage(message.tabId, {
        action: 'RUN_AUTOFILL_MANUAL',
        profileData: profilePayload
      }, () => {
        sendResponse({ success: true });
      });
    })();
    return true;
  }

  // 4. Page asks for profile data on load
  if (message.action === 'GET_ACTIVE_PROFILE_DATA') {
    (async () => {
      const storage = await chrome.storage.local.get(null);
      const password = storage.masterPassword || 'default-local-key';

      let profileNum = null;
      if (queue.active && queue.currentIndex < queue.profiles.length) {
        profileNum = queue.profiles[queue.currentIndex];
      } else if (storage.autoCheckoutEnabled === true) {
        profileNum = '1';
      }

      if (!profileNum) {
        sendResponse({ profileData: null });
        return;
      }

      const cipher = storage[`profile_${profileNum}`];
      if (!cipher) {
        sendResponse({ profileData: null });
        return;
      }

      const decrypted = await decryptData(cipher, password);
      sendResponse({
        profileData: decrypted
          ? {
              ...decrypted,
              profileNumber: profileNum,
              discountCode: queue.discount || storage.savedDiscountCode || '',
              webhookUrl: storage.discordWebhook || null
            }
          : null
      });
    })();
    return true;
  }

  // 5. Order Placed / Queue advancement
  if (message.action === 'CHECKOUT_COMPLETED') {
    if (queue.active) {
      queue.currentIndex++;
      if (queue.currentIndex < queue.profiles.length) {
        setTimeout(() => {
          safeNavigateTab(queue.cartUrl);
        }, 3500);
      } else {
        queue.active = false;
      }
    }
    sendResponse({ success: true });
    return true;
  }
});