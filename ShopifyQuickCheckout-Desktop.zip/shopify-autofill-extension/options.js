// options.js - Bulletproof Storage & Save Engine

document.addEventListener('DOMContentLoaded', () => {
  console.log('[Shopify Settings] Initializing options page...');

  const masterPasswordInput = document.getElementById('masterPassword');
  const discordWebhookInput = document.getElementById('discordWebhook');
  const emailInput = document.getElementById('email');
  const firstNameInput = document.getElementById('firstName');
  const lastNameInput = document.getElementById('lastName');
  const addressInput = document.getElementById('address');
  const address2Input = document.getElementById('address2');
  const cityInput = document.getElementById('city');
  const stateInput = document.getElementById('state');
  const zipInput = document.getElementById('zip');
  const phoneInput = document.getElementById('phone');
  const saveBtn = document.getElementById('saveBtn');
  const statusEl = document.getElementById('status');

  // --- 1. LOAD SAVED PROFILE VIA DIRECT CALLBACK ---
  chrome.storage.local.get(null, (storage) => {
    if (chrome.runtime.lastError) {
      console.error('[Shopify Settings] Error reading storage:', chrome.runtime.lastError);
      return;
    }

    storage = storage || {};
    const profile = storage.profile_1 || storage.lastCheckoutProfile || {};
    console.log('[Shopify Settings] Loaded existing storage:', storage);

    if (masterPasswordInput && storage.masterPassword) {
      masterPasswordInput.value = storage.masterPassword;
    }
    if (discordWebhookInput) {
      discordWebhookInput.value = profile.webhookUrl || storage.discordWebhook || '';
    }

    if (emailInput && profile.email) emailInput.value = profile.email;
    if (firstNameInput && profile.firstName) firstNameInput.value = profile.firstName;
    if (lastNameInput && profile.lastName) lastNameInput.value = profile.lastName;
    if (addressInput && (profile.address || profile.address1)) {
      addressInput.value = profile.address || profile.address1;
    }
    if (address2Input && profile.address2) address2Input.value = profile.address2;
    if (cityInput && profile.city) cityInput.value = profile.city;
    if (stateInput && profile.state) stateInput.value = profile.state;
    if (zipInput && (profile.zip || profile.postalCode)) {
      zipInput.value = profile.zip || profile.postalCode;
    }
    if (phoneInput && profile.phone) phoneInput.value = profile.phone;
  });

  // --- 2. SAVE PROFILE VIA SAFE CALLBACK ---
  if (!saveBtn) {
    console.error('[Shopify Settings] Could not find #saveBtn element in options.html!');
    return;
  }

  saveBtn.addEventListener('click', (e) => {
    e.preventDefault();
    console.log('[Shopify Settings] Save button clicked.');

    const masterPassword = masterPasswordInput?.value.trim() || 'default-local-key';
    const webhookUrl = discordWebhookInput?.value.trim() || '';

    const profilePayload = {
      email: emailInput?.value.trim() || '',
      firstName: firstNameInput?.value.trim() || '',
      lastName: lastNameInput?.value.trim() || '',
      address: addressInput?.value.trim() || '',
      address1: addressInput?.value.trim() || '',
      address2: address2Input?.value.trim() || '',
      city: cityInput?.value.trim() || '',
      state: stateInput?.value.trim() || '',
      zip: zipInput?.value.trim() || '',
      phone: phoneInput?.value.trim() || '',
      webhookUrl: webhookUrl
    };

    console.log('[Shopify Settings] Writing payload to chrome.storage.local:', profilePayload);

    chrome.storage.local.set({
      masterPassword: masterPassword,
      discordWebhook: webhookUrl,
      profile_1: profilePayload,
      lastCheckoutProfile: profilePayload
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('[Shopify Settings] Save failed:', chrome.runtime.lastError);
        if (statusEl) {
          statusEl.style.color = '#f87171';
          statusEl.textContent = '❌ Storage Error: ' + chrome.runtime.lastError.message;
        }
        return;
      }

      console.log('✅ [Shopify Settings] Storage write confirmed!');
      if (statusEl) {
        statusEl.style.color = '#10b981';
        statusEl.textContent = '✅ Profile & Settings saved successfully!';
        setTimeout(() => {
          statusEl.textContent = '';
        }, 3500);
      }
    });
  });
});