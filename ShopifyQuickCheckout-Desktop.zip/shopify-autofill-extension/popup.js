// popup.js

function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  const len = Math.max(parts1.length, parts2.length);
  for (let i = 0; i < len; i++) {
    const a = parts1[i] || 0;
    const b = parts2[i] || 0;
    if (a > b) return 1;
    if (a < b) return -1;
  }
  return 0;
}

async function checkForExtensionUpdates() {
  const banner = document.getElementById('update-banner');
  const bannerText = document.getElementById('update-banner-text');
  const versionDisplay = document.getElementById('version-display');
  const currentVersion = chrome.runtime.getManifest().version;

  if (versionDisplay) {
    versionDisplay.textContent = `v${currentVersion}`;
  }

  if (!banner || !bannerText) return;

  try {
    const res = await fetch(
      `https://raw.githubusercontent.com/JPxLA1/shopify-autofill-updater/main/updates.xml?t=${Date.now()}`,
      { cache: 'no-store' }
    );
    if (!res.ok) return;

    const xmlText = await res.text();
    const match = xmlText.match(/version=['"]([0-9.]+)['"]/i);
    if (!match) return;

    const latestVersion = match[1];
    if (compareVersions(latestVersion, currentVersion) > 0) {
      bannerText.textContent = `v${latestVersion} available (you have v${currentVersion})`;
      banner.style.display = 'flex';
    }
  } catch (err) {
    // Fail silently when offline
  }
}

function getFormProfileData() {
  return {
    email: document.getElementById('email').value.trim(),
    firstName: document.getElementById('firstName').value.trim(),
    lastName: document.getElementById('lastName').value.trim(),
    address: document.getElementById('address').value.trim(),
    address2: document.getElementById('address2').value.trim(),
    city: document.getElementById('city').value.trim(),
    state: document.getElementById('state').value.trim(),
    zip: document.getElementById('zip').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    discountCode: document.getElementById('discountCode').value.trim(),
    webhookUrl: document.getElementById('webhookUrl').value.trim()
  };
}

function showStatus(text) {
  const statusEl = document.getElementById('status-msg');
  if (!statusEl) return;
  statusEl.textContent = text;
  setTimeout(() => {
    statusEl.textContent = '';
  }, 2500);
}

function initPopup() {
  // 1. Check GitHub for newer release immediately
  checkForExtensionUpdates();

  // 2. Load saved profile & toggle state
  chrome.storage.local.get(['autoCheckoutEnabled', 'profile_1', 'discordWebhook'], (res) => {
    const toggle = document.getElementById('auto-checkout-toggle');
    if (toggle) {
      toggle.checked = Boolean(res.autoCheckoutEnabled);
    }

    const p = res.profile_1 || {};
    document.getElementById('email').value = p.email || '';
    document.getElementById('firstName').value = p.firstName || '';
    document.getElementById('lastName').value = p.lastName || '';
    document.getElementById('address').value = p.address || '';
    document.getElementById('address2').value = p.address2 || '';
    document.getElementById('city').value = p.city || '';
    document.getElementById('state').value = p.state || '';
    document.getElementById('zip').value = p.zip || '';
    document.getElementById('phone').value = p.phone || '';
    document.getElementById('discountCode').value = p.discountCode || '';
    document.getElementById('webhookUrl').value = p.webhookUrl || res.discordWebhook || '';
  });

  // 3. Auto-fill toggle listener
  document.getElementById('auto-checkout-toggle').addEventListener('change', (e) => {
    chrome.storage.local.set({ autoCheckoutEnabled: e.target.checked }, () => {
      showStatus(e.target.checked ? 'Auto-fill enabled' : 'Auto-fill paused');
    });
  });

  // 4. Save profile button
  document.getElementById('save-btn').addEventListener('click', () => {
    const profileData = getFormProfileData();
    chrome.storage.local.set(
      {
        profile_1: profileData,
        discordWebhook: profileData.webhookUrl || ''
      },
      () => {
        showStatus('Profile saved!');
      }
    );
  });

  // 5. Manual trigger button ("Run Filled Profile Now")
  document.getElementById('run-btn').addEventListener('click', async () => {
    const profileData = getFormProfileData();
    chrome.storage.local.set({
      profile_1: profileData,
      discordWebhook: profileData.webhookUrl || ''
    });

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return;

    // Broadcast to all frames in the active tab (handles top page + Stripe address iframe)
    chrome.tabs.sendMessage(tab.id, {
      action: 'RUN_AUTOFILL_MANUAL',
      profileData: profileData
    });

    showStatus('Running autofill on active tab...');
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPopup);
} else {
  initPopup();
}