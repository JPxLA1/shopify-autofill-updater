// content.js

// --- 1. React 18+ Controlled Input & Select Setters ---
function setFieldValue(input, value) {
  if (!input || value === undefined || value === null) return;

  input.focus();

  const isSelect = input.tagName === 'SELECT';
  const prototype = isSelect
    ? window.HTMLSelectElement.prototype
    : window.HTMLInputElement.prototype;

  const nativeSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;

  if (nativeSetter) {
    nativeSetter.call(input, value);
  } else {
    input.value = value;
  }

  if (input._valueTracker) {
    input._valueTracker.setValue('');
  }

  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new Event('blur', { bubbles: true }));
}

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

async function findField(selectors, timeout = 3000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    for (const sel of selectors) {
      try {
        const el = document.querySelector(sel);
        if (el && el.offsetParent !== null) return el;
      } catch (e) {}
    }
    await sleep(150);
  }
  return null;
}

// --- 2. Platform Detection ---
function isWooCommerce() {
  return Boolean(
    document.querySelector('form.woocommerce-checkout') ||
    document.querySelector('.wc-block-checkout') ||
    document.querySelector('#place_order[name="woocommerce_checkout_place_order"]')
  );
}

function isStripeAddressFrame() {
  const url = window.location.href.toLowerCase();
  return Boolean(
    (url.includes('js.stripe.com') && url.includes('address')) ||
    document.querySelector('#shippingAddress-firstNameInput, input[id^="shippingAddress-"]')
  );
}

function isSquarespaceOrEmbeddedAddress() {
  if (isStripeAddressFrame()) return true;

  const url = window.location.href.toLowerCase();
  const html = document.documentElement.innerHTML;
  return Boolean(
    url.includes('squarespace.com/checkout') ||
    document.body?.classList.contains('commerce-checkout') ||
    document.querySelector(
      '[data-test="checkout"], [data-test="opt-out"], .sqs-checkout, #sqs-checkout, button[data-testid="continue-button"], button[data-testid="continue-fulfillment-section-button"]'
    ) ||
    document.querySelector('script[src*="squarespace.com"], link[href*="squarespace.com"], script[src*="sqspcdn.com"]') ||
    html.includes('Static.SQUARESPACE_CONTEXT') ||
    html.includes('EnhancedInput-textInput')
  );
}

// --- 3. Multi-Item Order Summary Scraping ---
const IGNORED_SUMMARY_LABELS = /^(subtotal|sub-total|shipping|delivery|taxes?|estimated taxes?|total|total due|amount paid|discount|gift card|tip|duties|cost summary|order summary|quantity|free|\$[\d,.]+)$/i;

function isValidProductTitle(title) {
  if (!title) return false;
  const cleaned = title.trim();
  if (!cleaned || cleaned.length < 2) return false;
  if (IGNORED_SUMMARY_LABELS.test(cleaned)) return false;
  if (/^\$?\d+([.,]\d{2})?$/.test(cleaned)) return false;
  return true;
}

function getOrderItems() {
  const items = [];

  const rowElements = document.querySelectorAll(
    '[role="table"] [role="row"], aside [role="row"], aside table tbody tr, aside ul[role="list"] > li, aside [class*="line-item"], tr.product, div[data-checkout-line-item], tr.cart_item'
  );

  rowElements.forEach((row) => {
    const titleEl = row.querySelector(
      '.dDm6x p, [role="rowheader"], [role="cell"] p, p[class*="product-title"], .product__description__name, [class*="product__name"], [class*="line-item__title"], td.product-name, h3'
    );
    const title = titleEl ? titleEl.textContent.trim() : null;

    if (!isValidProductTitle(title)) return;

    let qty = '1';
    const qtySpan = Array.from(row.querySelectorAll('span')).find(
      (el) => el.textContent.trim().toLowerCase() === 'quantity'
    );
    if (qtySpan && qtySpan.parentElement) {
      const match = qtySpan.parentElement.textContent.replace(/quantity/i, '').trim().match(/\d+/);
      if (match) qty = match[0];
    } else {
      const badge = row.querySelector(
        '[aria-label*="Quantity"], .product-thumbnail__quantity, [class*="quantity-badge"], ._1fragem12, .product-quantity, [aria-hidden="true"]'
      );
      if (badge && /^\d+$/.test(badge.textContent.trim())) {
        qty = badge.textContent.trim();
      }
    }

    // Deduplicate identical titles
    if (!items.some((existing) => existing.title.toLowerCase() === title.toLowerCase())) {
      items.push({
        title: title,
        quantity: qty
      });
    }
  });

  if (items.length === 0) {
    const candidates = document.querySelectorAll('.dDm6x p, div[role="cell"] p, aside [role="cell"] p, [role="rowheader"]');
    for (const el of candidates) {
      const candidateTitle = el.textContent.trim();
      if (isValidProductTitle(candidateTitle)) {
        items.push({ title: candidateTitle, quantity: '1' });
        break;
      }
    }
  }

  return items;
}

function getTotalPrice() {
  const priceSelectors = [
    '[data-checkout-payment-due-target]',
    'aside [class*="payment-due__price"]',
    'aside [aria-label*="Total"]',
    'strong[class*="total-price"]',
    '[class*="paymentDue"]',
    '[class*="total-recap__final-price"]',
    '.order-total .woocommerce-Price-amount'
  ];
  for (const sel of priceSelectors) {
    const el = document.querySelector(sel);
    if (el && el.textContent.trim()) {
      return el.textContent.trim();
    }
  }
  return 'Free';
}

function getProductImage() {
  const img = document.querySelector('aside img, [role="table"] img, .product-thumbnail__image, img[src*="cdn.shopify.com/s/files"]');
  if (!img) return null;

  let rawUrl = '';
  if (img.srcset) {
    const sources = img.srcset.split(',').map((s) => s.trim().split(' ')[0]);
    rawUrl = sources[sources.length - 1] || img.src;
  } else {
    rawUrl = img.src || '';
  }

  if (!rawUrl || rawUrl.includes('svg')) return null;

  if (rawUrl.startsWith('//')) {
    rawUrl = 'https:' + rawUrl;
  }

  try {
    const urlObj = new URL(rawUrl);
    urlObj.searchParams.delete('width');
    urlObj.searchParams.delete('height');
    urlObj.searchParams.delete('crop');
    return urlObj.toString();
  } catch (e) {
    return rawUrl.replace(/([?&])(width|height|crop)=\d+/g, '');
  }
}

function isValidOrderCode(code) {
  if (!code) return false;
  const cleaned = code.replace(/^#/, '').trim();
  if (cleaned.length < 4 || cleaned.length > 20) return false;
  // Block DOM/CSS anchor IDs and common storefront prose words
  if (/^(summary|total|checkout|main|app|root|header|footer|order|confirmation|number|details|status|still|mobile|now|today|online|here|free|items?|complete|completed|confirmed|pending|processing|shipped|delivered|tracking|history|account)$/i.test(cleaned)) {
    return false;
  }
  return /^[A-Z0-9-]+$/i.test(cleaned);
}

function scrapeOrderNumber() {
  // Require explicit # or : after Confirmation / Order so prose like "Order Mobile" or "Order Complete" never matches
  const patterns = [
    /(?:Confirmation|Order)\s*(?:number|ID)?\s*(?:#|:)\s*([A-Z0-9-]{4,20})/i,
    /Confirmation\s+#([A-Z0-9-]{4,20})/i
  ];

  // 1. Check specific confirmation headers and text nodes first
  const candidates = Array.from(
    document.querySelectorAll('p, span, h1, h2, h3, [class*="os-order-number"], header h2, li.order strong')
  );
  for (const el of candidates) {
    const text = (el.innerText || el.textContent || '').trim();
    if (!text || text.length > 100) continue;
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && isValidOrderCode(match[1])) {
        const cleanCode = match[1].replace(/^#/, '');
        return `#${cleanCode}`;
      }
    }
  }

  // 2. Fallback to visible body text (innerText avoids hidden anchor hrefs like #summaryTotal)
  const bodyText = document.body.innerText || '';
  for (const pattern of patterns) {
    const bodyMatch = bodyText.match(pattern);
    if (bodyMatch && isValidOrderCode(bodyMatch[1])) {
      const cleanCode = bodyMatch[1].replace(/^#/, '');
      return `#${cleanCode}`;
    }
  }

  return null;
}

let webhookDispatched = false;
let webhookPending = false;

async function triggerWebhookIfConfirmed() {
  if (webhookDispatched || webhookPending || window.top !== window.self) return;

  const url = window.location.href.toLowerCase();

  // Never fire on customer account history or product/collection pages
  if (url.includes('/account') || url.includes('/products/') || url.includes('/collections/')) {
    return;
  }

  // Only fire on actual post-checkout confirmation URLs
  const isConfirmUrl =
    url.includes('thank_you') ||
    url.includes('thank-you') ||
    url.includes('post_purchase') ||
    url.includes('order-received') ||
    url.includes('order-confirmed') ||
    (url.includes('/checkouts/') && url.includes('/orders/'));

  // Or explicit confirmation heading on checkout/confirmation pages
  const hasConfirmationHeading = Array.from(document.querySelectorAll('h1, h2, h3')).some((h) => {
    const t = (h.innerText || '').trim().toLowerCase();
    return (
      t.startsWith('thank you') ||
      t.includes('order is confirmed') ||
      t.includes('order confirmed') ||
      t.includes('order received')
    );
  });

  if (!isConfirmUrl && !(hasConfirmationHeading && url.includes('checkout'))) {
    return;
  }

  webhookPending = true;

  // Wait briefly so React/SPA confirmation header & line items finish rendering
  let orderNum = scrapeOrderNumber();
  if (!orderNum) {
    await sleep(700);
    orderNum = scrapeOrderNumber();
  }

  webhookDispatched = true;
  webhookPending = false;

  chrome.storage.local.get(['discordWebhook', 'lastCheckoutProfile', 'profile_1'], (res) => {
    const webhookUrl = res.lastCheckoutProfile?.webhookUrl || res.discordWebhook;
    const finalOrder = orderNum || '#CONFIRMED';

    const liveItems = getOrderItems();
    const liveImage = getProductImage();
    const liveTotal = getTotalPrice();

    const items = (liveItems.length > 0) ? liveItems : (res.lastCheckoutProfile?.items || []);
    const thumbnail = liveImage || res.lastCheckoutProfile?.thumbnail;
    const totalDisplay = (liveTotal && liveTotal !== 'Free') ? liveTotal : (res.lastCheckoutProfile?.totalPrice || 'Free');
    const email = res.lastCheckoutProfile?.email || res.profile_1?.email || 'N/A';

    if (webhookUrl) {
      const formattedItemList = items.length > 0
        ? items.map((i) => `• **${i.title}** (Qty: ${i.quantity})`).join('\n')
        : 'N/A';

      const totalQty = items.length > 0
        ? items.reduce((sum, i) => sum + parseInt(i.quantity || '1', 10), 0)
        : 1;

      const fields = [
        { name: `Items Ordered (${items.length || 1})`, value: formattedItemList, inline: false },
        { name: 'Email', value: `||${email}||`, inline: true },
        { name: 'Order #', value: `||${finalOrder}||`, inline: true },
        { name: 'Total Quantity', value: totalQty.toString(), inline: true },
        { name: 'Total', value: totalDisplay, inline: true }
      ];

      chrome.runtime.sendMessage({
        action: 'SEND_DISCORD_WEBHOOK',
        webhookUrl: webhookUrl,
        payload: {
          embeds: [
            {
              title: 'JPxShopify Success',
              color: 3066993,
              fields: fields,
              thumbnail: thumbnail ? { url: thumbnail } : undefined,
              timestamp: new Date().toISOString()
            }
          ]
        }
      });
      console.log('✅ Webhook sent for order:', finalOrder);
    }
  });

  chrome.runtime.sendMessage({ action: 'CHECKOUT_COMPLETED' });
}

// Helper: Uncheck Shopify's "Email me with news and offers" checkbox if checked
function uncheckShopifyMarketing() {
  const marketingCheckbox = document.querySelector('#marketing_opt_in, input[name="marketing_opt_in"]');
  if (marketingCheckbox && marketingCheckbox.checked) {
    marketingCheckbox.click();
    if (marketingCheckbox.checked) {
      marketingCheckbox.checked = false;
      marketingCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
    }
    console.log('✅ Unchecked Shopify marketing opt-in checkbox.');
  }
}

// Helper: Ensure "Same as shipping address" is selected (Shopify & WooCommerce)
function ensureSameBillingAddress() {
  const wooShipDiffCheckbox = document.querySelector('#ship-to-different-address-checkbox');
  if (wooShipDiffCheckbox && wooShipDiffCheckbox.checked) {
    wooShipDiffCheckbox.click();
    wooShipDiffCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
    return;
  }

  const sameBillingRadio = document.querySelector(
    'input[type="radio"][name*="billing"][value*="same"], input[type="radio"][value="same"], input[id*="billing-address-same"], input[id*="billing_address_same"]'
  );
  if (sameBillingRadio && !sameBillingRadio.checked) {
    sameBillingRadio.click();
    sameBillingRadio.dispatchEvent(new Event('change', { bubbles: true }));
    return;
  }

  const labels = Array.from(document.querySelectorAll('label, [role="radio"], [data-subfields-for-flag]'));
  const sameLabel = labels.find((el) => {
    const txt = (el.innerText || el.textContent || '').toLowerCase();
    return txt.includes('same as shipping');
  });

  if (sameLabel) {
    const radioInside = sameLabel.querySelector('input[type="radio"]') || sameLabel;
    if (!radioInside.checked) {
      radioInside.click();
      radioInside.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return;
  }

  const billingCheckbox = document.querySelector(
    'input[type="checkbox"][name*="billing"], input[name="useShippingAsBilling"]'
  );
  if (billingCheckbox && !billingCheckbox.checked) {
    billingCheckbox.click();
    billingCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
  }
}

// Helper: Check WooCommerce Terms & Conditions checkbox if present
function acceptWooCommerceTerms() {
  const termsCheckbox =
    document.querySelector('#terms, input[name="terms"], input.woocommerce-form__input-checkbox[name="terms"]') ||
    document.querySelector('.woocommerce-terms-and-conditions-checkbox-text')?.closest('label')?.querySelector('input[type="checkbox"]');

  if (termsCheckbox && !termsCheckbox.checked) {
    termsCheckbox.click();
    if (!termsCheckbox.checked) {
      termsCheckbox.checked = true;
      termsCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
    }
    console.log('✅ Checked WooCommerce Terms & Conditions checkbox.');
  }
}

// --- 4. Squarespace & Embedded Stripe Address Handler (Works across frames) ---
let activeSqsProfile = null;
let sqsStepLock = false;
let stripeAddressFilled = false;

function clickSquarespaceContinue() {
  const testIdSelectors = [
    'button[data-testid="continue-button"]',
    'button[data-testid="continue-fulfillment-section-button"]'
  ];

  for (const sel of testIdSelectors) {
    const btn = document.querySelector(sel);
    if (btn && !btn.disabled && btn.offsetParent !== null) {
      btn.click();
      return true;
    }
  }

  const buttons = Array.from(document.querySelectorAll('button, input[type="submit"]'));
  const continueBtn = buttons.find((btn) => {
    if (btn.disabled || btn.offsetParent === null) return false;
    const text = (btn.innerText || btn.value || '').trim().toLowerCase();
    return text === 'continue' || text === 'save & continue' || text === 'next';
  });

  if (continueBtn) {
    continueBtn.click();
    return true;
  }
  return false;
}

async function handleSquarespaceStep(data) {
  if (!data || sqsStepLock) return;
  sqsStepLock = true;

  try {
    if (window.top === window.self) {
      chrome.storage.local.set({
        lastCheckoutProfile: {
          email: data.email,
          items: getOrderItems(),
          totalPrice: getTotalPrice(),
          thumbnail: getProductImage(),
          webhookUrl: data.webhookUrl || null
        }
      });

      // Step 0: Dismiss Express Checkout wall ("More payment options" / data-test="opt-out")
      const morePaymentBtn =
        document.querySelector('button[data-test="opt-out"][aria-label="More payment options"]') ||
        document.querySelector('button[data-test="opt-out"]');
      if (morePaymentBtn && !morePaymentBtn.disabled && morePaymentBtn.offsetParent !== null) {
        morePaymentBtn.click();
        console.log('✅ Clicked Squarespace "More payment options" button!');
        await sleep(350);
        return;
      }
    }

    // Step 1: Email section (Top Squarespace frame)
    const emailInput = document.querySelector(
      'input[name="email"][type="email"], input[autocomplete*="email"], input[type="email"]'
    );
    if (emailInput && emailInput.offsetParent !== null && data.email) {
      if (!emailInput.value || !emailInput.value.includes('@')) {
        setFieldValue(emailInput, data.email);
        await sleep(350);
        clickSquarespaceContinue();
        return;
      }
    }

    // Step 2: Shipping Address section (Inside Stripe Address Element iframe or Squarespace DOM)
    const fnameInput = document.querySelector(
      '#shippingAddress-firstNameInput, input[name="firstName"], input[name="fname"], input[autocomplete*="given-name"]'
    );
    if (fnameInput && fnameInput.offsetParent !== null && !stripeAddressFilled) {
      const sqsMap = [
        [['#shippingAddress-firstNameInput', 'input[name="firstName"]', 'input[name="fname"]', 'input[autocomplete*="given-name"]'], data.firstName],
        [['#shippingAddress-lastNameInput', 'input[name="lastName"]', 'input[name="lname"]', 'input[autocomplete*="family-name"]'], data.lastName],
        [['#shippingAddress-addressLine1Input', 'input[name="addressLine1"]', 'input[name="address1"]', 'input[autocomplete*="address-line1"]'], data.address || data.address1],
        [['#shippingAddress-addressLine2Input', 'input[name="addressLine2"]', 'input[name="address2"]', 'input[autocomplete*="address-line2"]'], data.address2 || data.apartment],
        [['#shippingAddress-localityInput', 'input[name="locality"]', 'input[name="city"]', 'input[autocomplete*="address-level2"]'], data.city],
        [['#shippingAddress-postalCodeInput', 'input[name="postalCode"]', 'input[name="zip"]', 'input[autocomplete*="postal-code"]'], data.zip || data.postalCode],
        [['#shippingAddress-phoneInput', 'input[name="phone"]', 'input[autocomplete*="tel"]'], data.phone]
      ];

      for (const [selectors, val] of sqsMap) {
        if (!val) continue;
        for (const sel of selectors) {
          const el = document.querySelector(sel);
          if (el && el.offsetParent !== null) {
            setFieldValue(el, val);
            await sleep(90);
            break;
          }
        }
      }

      // Close Google Places autocomplete dropdown on Address Line 1 if Stripe opened it
      const addr1El = document.querySelector('#shippingAddress-addressLine1Input');
      if (addr1El) {
        addr1El.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
        addr1El.blur();
      }

      // State <select> using React native prototype setter
      const stateSelect = document.querySelector(
        '#shippingAddress-administrativeAreaInput, select[name="administrativeArea"], select[name="state"], select[autocomplete*="address-level1"]'
      );
      if (stateSelect && stateSelect.offsetParent !== null) {
        const stateVal = data.state || 'California';
        const stateAbbr = (data.stateAbbr || (stateVal.toLowerCase().startsWith('cal') ? 'CA' : stateVal)).toUpperCase();
        for (const opt of stateSelect.options) {
          if (opt.value.toUpperCase() === stateAbbr || opt.text.trim().toLowerCase() === stateVal.toLowerCase()) {
            setFieldValue(stateSelect, opt.value);
            break;
          }
        }
      }

      stripeAddressFilled = true;
      console.log('✅ Filled Stripe/Squarespace Shipping Address!');

      await sleep(500);
      clickSquarespaceContinue();
      return;
    }

    // Step 3: Parent Squarespace frame Continue button once Stripe iframe reports valid address
    if (window.top === window.self && !emailInput) {
      const fulfillmentContinueBtn = document.querySelector(
        'button[data-testid="continue-fulfillment-section-button"], button[data-testid="continue-button"]'
      );
      if (fulfillmentContinueBtn && !fulfillmentContinueBtn.disabled && fulfillmentContinueBtn.offsetParent !== null) {
        await sleep(300);
        fulfillmentContinueBtn.click();
        console.log('✅ Clicked Squarespace Fulfillment Continue button!');
        return;
      }
    }

    // Step 4: Final Review / Freebie Submit ($0.00 only)
    const buttons = Array.from(document.querySelectorAll('button'));
    const purchaseBtn = buttons.find((b) => {
      const t = (b.innerText || '').trim().toLowerCase();
      return t === 'purchase' || t === 'place order' || t === 'complete order';
    });

    if (purchaseBtn && !purchaseBtn.disabled && purchaseBtn.offsetParent !== null) {
      const pageText = document.body.innerText || '';
      if (pageText.includes('$0.00') || pageText.toLowerCase().includes('free')) {
        purchaseBtn.click();
        console.log('✅ Clicked Squarespace Freebie Purchase button!');
      }
    }
  } finally {
    setTimeout(() => {
      sqsStepLock = false;
    }, 450);
  }
}

// --- 5. Core Autofill Routine (Shopify & WooCommerce) ---
async function executeAutofill(data) {
  if (!data) return;

  // Route Squarespace & embedded Stripe address frames to the step-by-step handler
  if (isSquarespaceOrEmbeddedAddress()) {
    activeSqsProfile = data;
    await handleSquarespaceStep(data);
    return;
  }

  // Never run Shopify/WooCommerce logic inside an iframe
  if (window.top !== window.self) return;

  const woo = isWooCommerce();
  console.log(`⚡ Autofilling Profile (${woo ? 'WooCommerce' : 'Shopify'}):`, data.email);

  // 1. Email & Uncheck Shopify Marketing Opt-In
  const emailInput = await findField([
    'input[name="email"]',
    '#billing_email',
    'input[name="billing_email"]',
    'input[autocomplete*="email"]',
    'input[type="email"]',
    '#email'
  ], 1200);

  if (emailInput && data.email) {
    setFieldValue(emailInput, data.email);
    await sleep(150);
  }

  if (!woo) {
    uncheckShopifyMarketing();
  }

  // 2. First Name & Last Name
  const firstNameInput = await findField([
    'input[name="firstName"]',
    '#billing_first_name',
    '#billing-first_name',
    'input[name="billing_first_name"]',
    'input[autocomplete*="given-name"]',
    'input[placeholder*="First name" i]'
  ]);

  const lastNameInput = await findField([
    'input[name="lastName"]',
    '#billing_last_name',
    '#billing-last_name',
    'input[name="billing_last_name"]',
    'input[autocomplete*="family-name"]',
    'input[placeholder*="Last name" i]'
  ]);

  if (firstNameInput && data.firstName) setFieldValue(firstNameInput, data.firstName);
  if (lastNameInput && data.lastName) setFieldValue(lastNameInput, data.lastName);
  await sleep(150);

  // 3. Address Line 1
  const addressInput = await findField([
    'input[name="address1"]',
    '#billing_address_1',
    '#billing-address_1',
    'input[name="billing_address_1"]',
    'input[autocomplete*="address-line1"]',
    '#shipping-address1',
    'input[placeholder*="Address" i]:not([placeholder*="Apartment" i]):not([placeholder*="Email" i]):not([type="email"]):not([name="email"])'
  ]);
  if (addressInput && (data.address || data.address1)) {
    setFieldValue(addressInput, data.address || data.address1);
  }

  // 4. Apartment / Suite / Line 2 (Optional)
  const aptVal = data.address2 || data.apartment || '';
  if (aptVal) {
    const aptInput = await findField([
      'input[name="address2"]',
      '#billing_address_2',
      '#billing-address_2',
      'input[name="billing_address_2"]',
      'input[autocomplete*="address-line2"]',
      'input[placeholder*="Apartment" i]',
      '#shipping-address2'
    ], 1000);

    if (aptInput) {
      setFieldValue(aptInput, aptVal);
    }
  }

  // 5. City, ZIP, Phone
  const cityInput = await findField([
    'input[name="city"]',
    '#billing_city',
    '#billing-city',
    'input[name="billing_city"]',
    'input[autocomplete*="address-level2"]',
    'input[placeholder*="City" i]'
  ]);

  const zipInput = await findField([
    'input[name="postalCode"]',
    '#billing_postcode',
    '#billing-postcode',
    'input[name="billing_postcode"]',
    'input[autocomplete*="postal-code"]',
    'input[placeholder*="ZIP" i]',
    'input[placeholder*="Postal" i]'
  ]);

  const phoneInput = await findField([
    'input[name="phone"]',
    '#billing_phone',
    '#billing-phone',
    'input[name="billing_phone"]',
    'input[autocomplete*="tel"]',
    'input[type="tel"]',
    'input[placeholder*="Phone" i]'
  ]);

  if (cityInput && data.city) setFieldValue(cityInput, data.city);
  if (zipInput && (data.zip || data.postalCode)) setFieldValue(zipInput, data.zip || data.postalCode);
  if (phoneInput && data.phone) setFieldValue(phoneInput, data.phone);

  // 6. State / Zone Selection
  const stateVal = data.state || 'California';
  const stateAbbr = (data.stateAbbr || (stateVal.toLowerCase().startsWith('cal') ? 'CA' : stateVal)).toUpperCase();

  const select = document.querySelector(
    'select[name="zone"], #billing_state, #billing-state, select[name="billing_state"], select[autocomplete*="address-level1"]'
  );
  if (select) {
    for (const opt of select.options) {
      if (
        opt.value.toUpperCase() === stateAbbr ||
        opt.text.trim().toLowerCase() === stateVal.toLowerCase()
      ) {
        setFieldValue(select, opt.value);
        break;
      }
    }
  } else {
    const stateInput = document.querySelector(
      'input[name="zone"], input[name="billing_state"], input[autocomplete*="address-level1"]'
    );
    if (stateInput) setFieldValue(stateInput, stateAbbr);
  }

  // 7. Ensure Same as Shipping is chosen for Billing & Marketing stays unchecked
  ensureSameBillingAddress();
  if (!woo) {
    uncheckShopifyMarketing();
  }

  // 8. Discount Code
  if (data.discountCode) {
    const discountInput = document.querySelector('input[name="reductions"], input[id*="reduction-code"], #coupon_code');
    if (discountInput) {
      setFieldValue(discountInput, data.discountCode);
      await sleep(300);
      const applyBtn = document.querySelector(
        'button[aria-label="Apply Discount Code"], button[id*="apply-discount"], button[name="apply_coupon"]'
      );
      if (applyBtn && !applyBtn.disabled) {
        applyBtn.click();
        await sleep(1500);
      }
    }
  }

  await sleep(600);

  // 9. Re-verify Same as Shipping & WooCommerce Terms before submitting
  ensureSameBillingAddress();
  if (woo) {
    acceptWooCommerceTerms();
    await sleep(250);
  }

  // 10. Submit Order
  const findPayButton = () => {
    if (woo) {
      return (
        document.querySelector('#place_order[name="woocommerce_checkout_place_order"]') ||
        document.querySelector('#place_order') ||
        document.querySelector('.wc-block-components-checkout-place-order-button')
      );
    }

    return (
      document.querySelector('#checkout-pay-button') ||
      document.querySelector('button[data-event-name="pay_button_inline"]') ||
      Array.from(document.querySelectorAll('button')).find((b) => {
        const text = (b.innerText || '').toLowerCase();
        return (
          text.includes('complete order') ||
          text.includes('pay now') ||
          text.includes('place order')
        );
      })
    );
  };

  const preCheckoutImage = getProductImage();
  const preCheckoutItems = getOrderItems();
  const preCheckoutTotal = getTotalPrice();

  await new Promise((resolve) => {
    chrome.storage.local.set({
      lastCheckoutProfile: {
        email: data.email,
        items: preCheckoutItems,
        totalPrice: preCheckoutTotal,
        thumbnail: preCheckoutImage,
        webhookUrl: data.webhookUrl || null
      }
    }, resolve);
  });

  // For WooCommerce freebies, verify $0.00 before auto-clicking #place_order
  if (woo) {
    const totalClean = preCheckoutTotal.replace(/[^0-9.]/g, '');
    const isFreebie = totalClean === '' || parseFloat(totalClean) === 0;
    if (!isFreebie) {
      console.log('⚡ WooCommerce order is not $0.00; skipping auto-click.');
      return;
    }
  }

  for (let attempt = 0; attempt < 15; attempt++) {
    if (woo) {
      acceptWooCommerceTerms();
    }

    const payBtn = findPayButton();
    if (payBtn) {
      const isBusy =
        payBtn.getAttribute('aria-busy') === 'true' ||
        Boolean(document.querySelector('.blockUI.blockOverlay'));
      if (!isBusy && !payBtn.disabled && payBtn.offsetParent !== null) {
        payBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        payBtn.click();
        console.log(`✅ Clicked ${woo ? 'WooCommerce #place_order' : 'Complete Order'} button!`);
        break;
      }
    }
    await sleep(300);
  }
}

// --- 6. Execution Triggers & DOM Watcher ---
function loadAndRunAutofill() {
  chrome.storage.local.get(['autoCheckoutEnabled', 'profile_1', 'lastCheckoutProfile', 'discordWebhook'], (res) => {
    if (!res.autoCheckoutEnabled) {
      return;
    }

    chrome.runtime.sendMessage({ action: 'GET_ACTIVE_PROFILE_DATA' }, (response) => {
      if (response && response.profileData) {
        executeAutofill(response.profileData);
      } else {
        const fallbackProfile = res.profile_1 || res.lastCheckoutProfile;
        if (fallbackProfile && (fallbackProfile.email || fallbackProfile.firstName || fallbackProfile.address)) {
          if (!fallbackProfile.webhookUrl && res.discordWebhook) {
            fallbackProfile.webhookUrl = res.discordWebhook;
          }
          executeAutofill(fallbackProfile);
        }
      }
    });
  });
}

(async () => {
  await triggerWebhookIfConfirmed();

  const observer = new MutationObserver(() => {
    triggerWebhookIfConfirmed();
    if (isSquarespaceOrEmbeddedAddress()) {
      if (activeSqsProfile) {
        handleSquarespaceStep(activeSqsProfile);
      } else {
        loadAndRunAutofill();
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

  const url = window.location.href.toLowerCase();
  const isCheckoutContext =
    url.includes('/checkouts/') ||
    url.includes('/checkout') ||
    url.includes('js.stripe.com') ||
    isWooCommerce() ||
    isSquarespaceOrEmbeddedAddress();

  if (!isCheckoutContext) {
    return;
  }

  // 1. Run initial check (works in both top frame and Stripe Address Element iframe)
  loadAndRunAutofill();

  // 2. Always listen for manual triggers from the popup ("Run Filled Profile" button)
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'RUN_AUTOFILL_MANUAL' && msg.profileData) {
      stripeAddressFilled = false;
      executeAutofill(msg.profileData);
      sendResponse({ status: 'MANUAL_RUN_STARTED' });
    }
  });
})();